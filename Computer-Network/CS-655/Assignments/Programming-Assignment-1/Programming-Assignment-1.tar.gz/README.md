# READ ME

Xueyan Xia U82450191 Ziqi Tan U88387934

## file structure
- src
    - part1
        - Client.java
        - ClientThread.java
        - Server.java
        - ServerThread.java
    - part2
        - Client.java
        - ClientThread.java
        - Server.java
        - ServerThread.java
        - ConnectInfo.java


## how to run
- Part 1
    1. Run Server.java.
    2. Run Client.java.

- Part 2
    1. Run Server.java.
    2. Run Client.java.

    RTT test and throughput test are included in main method in Server.java.

